
Hehe it wasn't actually a mod, now you have a virus on your computer

Ok but seriously, thanks for downloading my mod! Quick reminder that the mod is
currently a Work In Progress, and very early in development. There are lots of bugs
and stuff but they'll be fixed when the mod is done.

I also have a Youtube channel (thats dead af) and I'll be showcasing new updates
for this mod if you're intrested in seeing its developement.

Also, I hope you know how to install mods to FNF cuz I didn't include the actual game
into this zip file. If you dont, well..

Not my problem ¯\_(ツ)_/¯

I'll make a mod installation tutorial at a later update tho!